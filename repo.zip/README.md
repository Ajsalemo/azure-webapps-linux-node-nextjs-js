# azure-webapps-linux-node-nextjs-js
A very basic Next.js application used to test deployment scenarios on Azure.
